# HeatherMataruse_MiniProject_Week3


### Use of images/icons/widgets
-I used icons to make the app more apealing and easy to use
-I use things like  button so that the user can press to start their shopping or 
navigation
-I made sure the size of my images were the same and the thing i did not implement was 
making the images to be scrollable as it needed them to be in a container
-For my text I decided to use lobster thus also making the text in wigets because 
I needed to put the text in a rectangle box to make sure mt text is aligned


### How the simple app works

This project works when it loads and then you home to press
the welcome buttom which is at the landing page you see 
and then it will take you to the products page where you cam see 
the products on the platform
