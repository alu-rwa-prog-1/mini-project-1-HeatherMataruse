import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedhomepagewidget/generated/GeneratedButtonWidget.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedhomepagewidget/generated/GeneratedLogoWidget.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedhomepagewidget/generated/GeneratedWelcomeTextWidget.dart';

/*  Homepage
   
  */
class GeneratedHomepageWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: ClipRRect(
      borderRadius: BorderRadius.zero,
      child: Container(
        width: 360.0,
        height: 640.0,
        child: Stack(
            fit: StackFit.expand,
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.zero,
                child: Container(
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.zero,
                child: Image.asset(
                  "assets/images/785ace26bf7fb3b42f2e195ec91abb06f66de0c8.png",
                  color: null,
                  fit: BoxFit.cover,
                  width: 360.0,
                  height: 640.0,
                  colorBlendMode: BlendMode.dstATop,
                ),
              ),
              Positioned(
                left: 48.0,
                top: 548.0,
                right: null,
                bottom: null,
                width: 276.0,
                height: 46.0,
                child: GeneratedButtonWidget(),
              ),
              Positioned(
                left: 117.0,
                top: 558.0,
                right: null,
                bottom: null,
                width: 127.0,
                height: 26.0,
                child: GeneratedWelcomeTextWidget(),
              ),
              Positioned(
                left: 128.0,
                top: 22.0,
                right: null,
                bottom: null,
                width: 93.0,
                height: 113.0,
                child: GeneratedLogoWidget(),
              )
            ]),
      ),
    ));
  }
}
