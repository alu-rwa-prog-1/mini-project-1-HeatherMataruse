import 'package:flutter/material.dart';

/* Rectangle Button
    
  */
class GeneratedButtonWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/GeneratedProductsPageWidget'),
      child: Container(
        width: 276.0,
        height: 46.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: Container(
            color: Color.fromARGB(255, 239, 28, 129),
          ),
        ),
      ),
    );
  }
}
