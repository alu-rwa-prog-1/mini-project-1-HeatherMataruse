import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget1.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget2.dart';

/*  SearchIcon
    
  */
class GeneratedSearchIconWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 20.0,
      height: 20.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: null,
              bottom: null,
              width: 20.0,
              height: 20.0,
              child: GeneratedVectorWidget(),
            ),
            Positioned(
              left: 2.5,
              top: 2.5,
              right: null,
              bottom: null,
              width: 13.125,
              height: 13.125,
              child: GeneratedVectorWidget1(),
            ),
            Positioned(
              left: 13.70269775390625,
              top: 13.703155517578125,
              right: null,
              bottom: null,
              width: 3.7969207763671875,
              height: 3.7969207763671875,
              child: GeneratedVectorWidget2(),
            )
          ]),
    );
  }
}
