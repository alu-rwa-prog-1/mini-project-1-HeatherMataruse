import 'package:flutter/material.dart';

/* Vector 
  */
class GeneratedVectorWidget3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32.0,
      height: 32.0,
    );
  }
}
