import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget3.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget4.dart';

/* Group Favorites
   
  */
class GeneratedFavoritesWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32.0,
      height: 32.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: null,
              bottom: null,
              width: 32.0,
              height: 32.0,
              child: GeneratedVectorWidget3(),
            ),
            Positioned(
              left: 3.5,
              top: 5.0,
              right: null,
              bottom: null,
              width: 25.0,
              height: 22.000009536743164,
              child: GeneratedVectorWidget4(),
            )
          ]),
    );
  }
}
