import 'package:flutter/material.dart';

/* Rectangle Lotions
    
  */
class GeneratedLotionsWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/c6f6deb33a2e764f08296a16398549e6a57fac2b.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
