import 'package:flutter/material.dart';
import 'package:flutterapp/helpers/svg/svg.dart';

/* Vector
  */
class GeneratedVectorWidget2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 3.7969207763671875,
      height: 3.7969207763671875,
      child: SvgWidget(painters: [
        SvgPathPainter.stroke(
          2.0,
          strokeCap: StrokeCap.round,
          strokeJoin: StrokeJoin.miter,
        )
          ..addPath(
              'M0.707107 -0.707107C0.316583 -1.09763 -0.316583 -1.09763 -0.707107 -0.707107C-1.09763 -0.316583 -1.09763 0.316583 -0.707107 0.707107L0.707107 -0.707107ZM3.08981 4.50403C3.48034 4.89455 4.1135 4.89455 4.50403 4.50403C4.89455 4.1135 4.89455 3.48034 4.50403 3.08981L3.08981 4.50403ZM-0.707107 0.707107L3.08981 4.50403L4.50403 3.08981L0.707107 -0.707107L-0.707107 0.707107Z')
          ..color = Color.fromARGB(255, 58, 88, 186),
      ]),
    );
  }
}
