import 'package:flutter/material.dart';

/* Rectangle Lipgloss
    
  */
class GeneratedLipglossWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/076ad1b958c4ea83276c7eb4fcf2e435e6c4adba.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
