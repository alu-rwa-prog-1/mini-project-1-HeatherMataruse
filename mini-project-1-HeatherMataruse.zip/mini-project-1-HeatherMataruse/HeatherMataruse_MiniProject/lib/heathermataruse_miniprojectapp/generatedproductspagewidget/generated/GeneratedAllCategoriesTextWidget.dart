import 'package:flutter/material.dart';

/* Text All Categories Text
    
  */
class GeneratedAllCategoriesTextWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      '''All Categories''',
      overflow: TextOverflow.visible,
      textAlign: TextAlign.left,
      style: TextStyle(
        height: 1.171875,
        fontSize: 20.0,
        fontFamily: 'Lobster',
        fontWeight: FontWeight.w400,
        color: Color.fromARGB(255, 0, 0, 0),

        /* letterSpacing: 0.0, */
      ),
    );
  }
}
