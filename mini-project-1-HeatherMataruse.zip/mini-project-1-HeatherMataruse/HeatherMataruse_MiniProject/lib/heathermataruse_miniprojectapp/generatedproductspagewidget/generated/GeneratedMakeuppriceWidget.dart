import 'package:flutter/material.dart';

/* Text Makeup price : 
    
  */
class GeneratedMakeuppriceWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return RichText(
        overflow: TextOverflow.visible,
        textAlign: TextAlign.center,
        text: const TextSpan(
          style: TextStyle(
            height: 1.171875,
            fontSize: 15.0,
            fontFamily: 'Lobster',
            fontWeight: FontWeight.w400,
            color: Color.fromARGB(255, 0, 0, 0),

            /* letterSpacing: 0.0, */
          ),
          children: [
            TextSpan(
              text: '''Makeup
''',
            ),
            TextSpan(
              text: '''price : Rwf 30 000
''',
              style: TextStyle(
                fontSize: 10.0,

                /* letterSpacing: null, */
              ),
            )
          ],
        ));
  }
}
