import 'package:flutter/material.dart';

/* Rectangle Makeup
    
  */
class GeneratedMakeupWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/122d5dcb6d0bd1e583f853a0a900254ffc3f6f70.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
