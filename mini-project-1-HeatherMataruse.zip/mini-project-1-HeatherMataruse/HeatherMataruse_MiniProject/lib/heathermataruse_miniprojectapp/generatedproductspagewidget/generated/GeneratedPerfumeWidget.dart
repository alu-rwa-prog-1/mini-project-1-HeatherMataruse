import 'package:flutter/material.dart';

/* Rectangle Perfume
    
  */
class GeneratedPerfumeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/2226f795648e5b9d5975c12d7089528ed5553821.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
