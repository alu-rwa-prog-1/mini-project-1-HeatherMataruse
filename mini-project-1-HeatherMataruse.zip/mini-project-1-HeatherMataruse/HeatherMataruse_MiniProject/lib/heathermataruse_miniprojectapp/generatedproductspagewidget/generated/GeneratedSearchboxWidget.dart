import 'package:flutter/material.dart';
import 'package:flutterapp/helpers/transform/transform.dart';

/* Rectangle Searchbox
    
  */
class GeneratedSearchboxWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return TransformHelper.translate(
        x: -3.00,
        y: -3.00,
        z: 0,
        child: Container(
          width: 347.0,
          height: 39.0,
          decoration: BoxDecoration(
            border: Border.all(
              width: 3.0,
              color: Color.fromARGB(255, 239, 28, 129),
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.zero,
            child: Container(
              color: Color.fromARGB(255, 249, 249, 249),
            ),
          ),
        ));
  }
}
