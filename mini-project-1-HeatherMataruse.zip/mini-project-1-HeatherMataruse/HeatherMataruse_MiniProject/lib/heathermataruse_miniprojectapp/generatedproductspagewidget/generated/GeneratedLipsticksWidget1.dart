import 'package:flutter/material.dart';

/* Rectangle Lipsticks
    
  */
class GeneratedLipsticksWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/1a67832f4a0de86e8c7d88bae7f3377606074155.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
