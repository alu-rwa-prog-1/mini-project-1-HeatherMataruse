import 'package:flutter/material.dart';

/* Rectangle Foundations
    
  */
class GeneratedFoundationsWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92.0,
      height: 80.0,
      child: ClipRRect(
        borderRadius: BorderRadius.zero,
        child: Image.asset(
          "assets/images/43ef100cb20a71001b39c0053634b6a56ef2f2e6.png",
          color: null,
          fit: BoxFit.cover,
          width: 92.0,
          height: 80.0,
          colorBlendMode: BlendMode.dstATop,
        ),
      ),
    );
  }
}
