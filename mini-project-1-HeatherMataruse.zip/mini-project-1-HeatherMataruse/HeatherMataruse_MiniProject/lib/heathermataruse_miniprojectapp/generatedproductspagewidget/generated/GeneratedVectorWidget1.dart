import 'package:flutter/material.dart';
import 'package:flutterapp/helpers/svg/svg.dart';

/*  Vector
    
  */
class GeneratedVectorWidget1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 13.125,
      height: 13.125,
      child: SvgWidget(painters: [
        SvgPathPainter.stroke(
          2.0,
          strokeCap: StrokeCap.round,
          strokeJoin: StrokeJoin.miter,
        )
          ..addPath(
              'M12.125 6.5625C12.125 9.63458 9.63458 12.125 6.5625 12.125L6.5625 14.125C10.7392 14.125 14.125 10.7392 14.125 6.5625L12.125 6.5625ZM6.5625 12.125C3.49042 12.125 1 9.63458 1 6.5625L-1 6.5625C-1 10.7392 2.38585 14.125 6.5625 14.125L6.5625 12.125ZM1 6.5625C1 3.49042 3.49042 1 6.5625 1L6.5625 -1C2.38585 -1 -1 2.38585 -1 6.5625L1 6.5625ZM6.5625 1C9.63458 1 12.125 3.49042 12.125 6.5625L14.125 6.5625C14.125 2.38585 10.7392 -1 6.5625 -1L6.5625 1Z')
          ..color = Color.fromARGB(255, 58, 88, 186),
      ]),
    );
  }
}
