import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget13.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget12.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget14.dart';

/* Group MyAccount
    
  */
class GeneratedMyAccountWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32.0,
      height: 32.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: null,
              bottom: null,
              width: 32.0,
              height: 32.0,
              child: GeneratedVectorWidget12(),
            ),
            Positioned(
              left: 8.0,
              top: 4.0,
              right: null,
              bottom: null,
              width: 16.0,
              height: 16.0,
              child: GeneratedVectorWidget13(),
            ),
            Positioned(
              left: 3.87353515625,
              top: 20.0,
              right: null,
              bottom: null,
              width: 24.25288963317871,
              height: 6.999080657958984,
              child: GeneratedVectorWidget14(),
            )
          ]),
    );
  }
}
