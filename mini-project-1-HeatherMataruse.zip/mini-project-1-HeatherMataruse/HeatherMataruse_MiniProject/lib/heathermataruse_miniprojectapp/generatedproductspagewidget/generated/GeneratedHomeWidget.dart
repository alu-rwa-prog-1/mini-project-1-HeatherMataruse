import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget10.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget11.dart';

/* Group Home
    
  */
class GeneratedHomeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32.0,
      height: 32.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: null,
              bottom: null,
              width: 32.0,
              height: 32.0,
              child: GeneratedVectorWidget10(),
            ),
            Positioned(
              left: 5.0,
              top: 4.3504638671875,
              right: null,
              bottom: null,
              width: 22.0,
              height: 22.649402618408203,
              child: GeneratedVectorWidget11(),
            )
          ]),
    );
  }
}
