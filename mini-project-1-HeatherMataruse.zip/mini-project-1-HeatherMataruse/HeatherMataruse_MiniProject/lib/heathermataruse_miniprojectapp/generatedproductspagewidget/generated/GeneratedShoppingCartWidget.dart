import 'package:flutter/material.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget8.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget9.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget7.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget5.dart';
import 'package:flutterapp/heathermataruse_miniprojectapp/generatedproductspagewidget/generated/GeneratedVectorWidget6.dart';

/*  ShoppingCart
    
  */
class GeneratedShoppingCartWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 32.0,
      height: 32.0,
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0.0,
              top: 0.0,
              right: null,
              bottom: null,
              width: 32.0,
              height: 32.0,
              child: GeneratedVectorWidget5(),
            ),
            Positioned(
              left: 1.0,
              top: 3.0,
              right: null,
              bottom: null,
              width: 23.0,
              height: 20.0,
              child: GeneratedVectorWidget6(),
            ),
            Positioned(
              left: 6.5,
              top: 23.0,
              right: null,
              bottom: null,
              width: 5.0,
              height: 5.0,
              child: GeneratedVectorWidget7(),
            ),
            Positioned(
              left: 21.5,
              top: 23.0,
              right: null,
              bottom: null,
              width: 5.0,
              height: 5.0,
              child: GeneratedVectorWidget8(),
            ),
            Positioned(
              left: 5.0,
              top: 8.0,
              right: null,
              bottom: null,
              width: 22.80179214477539,
              height: 11.0,
              child: GeneratedVectorWidget9(),
            )
          ]),
    );
  }
}
