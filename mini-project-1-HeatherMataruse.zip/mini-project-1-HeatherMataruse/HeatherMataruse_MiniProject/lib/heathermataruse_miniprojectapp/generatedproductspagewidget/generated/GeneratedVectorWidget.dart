import 'package:flutter/material.dart';

/* Vector Vector
    
  */
class GeneratedVectorWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 20.0,
      height: 20.0,
    );
  }
}
